# EnG_ProjectA
 Model-Based Design to create a simple interface for building Quantum Machine Learning (QML) pipelines
